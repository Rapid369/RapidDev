const express = require('express');
const CodeExecutionService = require('../services/codeExecutionService');
const router = express.Router();

router.post('/execute', async (req, res) => {
  try {
    console.log('Received request to execute code.');
    const { language, code } = req.body;
    if (!language || !code) {
      console.log('Invalid request: Missing language or code.');
      return res.status(400).json({ success: false, message: 'Missing language or code in request.' });
    }
    const output = await CodeExecutionService.executeCode(language, code);
    console.log('Code execution completed successfully.');
    res.json({ success: true, output });
  } catch (error) {
    console.error('Failed to execute code:', error.message);
    console.error(error.stack);
    res.status(500).json({ success: false, message: 'Failed to execute code.', error: error.message });
  }
});

module.exports = router;
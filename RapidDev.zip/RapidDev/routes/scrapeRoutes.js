const express = require('express');
const router = express.Router();
const WebScraper = require('../services/webScraper');

router.get('/scrape/practices', async (req, res) => {
  try {
    console.log("Initiating scraping of coding practices.");
    const practices = await WebScraper.scrapeCodingPractices();
    console.log("Successfully scraped coding practices.");
    res.json({ success: true, data: practices });
  } catch (error) {
    console.error(`Scrape error: ${error.message}`);
    console.error(error.stack);
    res.status(500).send('Failed to scrape coding practices.');
  }
});

router.get('/scrape/documentation', async (req, res) => {
  try {
    console.log("Initiating scraping of documentation.");
    const documentation = await WebScraper.scrapeDocumentation();
    console.log("Successfully scraped documentation.");
    res.json({ success: true, data: documentation });
  } catch (error) {
    console.error(`Scrape error: ${error.message}`);
    console.error(error.stack);
    res.status(500).send('Failed to scrape documentation.');
  }
});

module.exports = router;
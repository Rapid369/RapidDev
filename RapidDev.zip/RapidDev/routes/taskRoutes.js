const express = require('express');
const router = express.Router();
const TaskManager = require('../controllers/taskManager');

router.post('/task', async (req, res) => {
  try {
    const { description, type } = req.body;
    await TaskManager.createAndAssignTask(description, type);
    console.log(`Task created and assigned successfully: ${description}, Type: ${type}`);
    res.status(200).json({ message: 'Task created and assigned successfully' });
  } catch (error) {
    console.error(`Failed to create and assign task. Error: ${error.message}`, error.stack);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
  description: { type: String, required: true },
  status: { type: String, required: true, enum: ['pending', 'in_progress', 'completed', 'failed'], default: 'pending' },
  result: { type: mongoose.Schema.Types.Mixed },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

taskSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  console.log(`Updating task: ${this._id} at ${this.updatedAt}`);
  next();
});

const Task = mongoose.model('Task', taskSchema);

module.exports = Task;
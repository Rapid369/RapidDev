const mongoose = require('mongoose');

const codingResourceSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: ['practice', 'documentation'],
    required: true
  },
  content: mongoose.Schema.Types.Mixed,
  scrapedAt: {
    type: Date,
    default: Date.now
  }
});

codingResourceSchema.pre('save', function(next) {
  console.log(`Saving a new coding resource of type: ${this.type}`);
  next();
});

codingResourceSchema.post('save', function(doc) {
  console.log(`Successfully saved coding resource with id: ${doc._id}`);
});

const CodingResource = mongoose.model('CodingResource', codingResourceSchema);

module.exports = CodingResource;
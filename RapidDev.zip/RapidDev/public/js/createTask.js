document.getElementById('taskForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const description = document.getElementById('description').value;
  const type = document.getElementById('type').value;

  if (description.length === 0) {
    alert('Description is required.');
    return;
  }

  if (type !== 'AI' && type !== 'scraping') {
    alert('Invalid type selected.');
    return;
  }

  fetch('/task', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ description, type }),
  })
  .then(response => {
    if (!response.ok) {
      console.error('Network response was not ok');
      throw new Error('Network response was not ok');
    }
    return response.json();
  })
  .then(data => {
    console.log('Task created successfully:', data);
    alert('Task created successfully');
    window.location.href = '/';
  })
  .catch((error) => {
    console.error('Error creating task:', error.message, error.stack);
    alert('Failed to create task');
  });
});
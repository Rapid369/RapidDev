window.onload = function() {
  fetch('/tasks', {
    method: 'GET',
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    return response.json();
  })
  .then(data => {
    const tasksList = document.getElementById('tasksList');
    if (!tasksList) {
      console.error('Tasks list element not found');
      return;
    }
    data.forEach(task => {
      const item = document.createElement('div');
      item.innerHTML = `Description: ${task.description} - Status: ${task.status}`;
      tasksList.appendChild(item);
    });
    console.log('Tasks loaded successfully');
  })
  .catch((error) => {
    console.error('Error loading tasks:', error.message, error.stack);
    alert('Failed to load tasks');
  });
};
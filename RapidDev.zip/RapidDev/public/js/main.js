// Check if user is logged in by checking the session token in localStorage
function checkLoginStatus() {
  const userSession = localStorage.getItem('userSession');
  if (!userSession) {
    window.location.href = '/auth/login'; // Redirect to login page if not logged in
  }
}

// Call checkLoginStatus on every page load to protect secure pages
window.onload = function() {
  checkLoginStatus();
};

// Logout function to clear localStorage and redirect to login
function logout() {
  localStorage.removeItem('userSession');
  window.location.href = '/auth/login';
}

// Attach logout function to logout button if it exists
const logoutButton = document.getElementById('logoutButton');
if (logoutButton) {
  logoutButton.addEventListener('click', logout);
}
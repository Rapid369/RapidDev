const axios = require('axios');

class AIService {
  constructor() {
    this.openAiUrl = process.env.OPENAI_URL;
    this.anthropicUrl = process.env.ANTHROPIC_URL;
    this.openAiApiKey = process.env.OPENAI_API_KEY;
    this.anthropicApiKey = process.env.ANTHROPIC_API_KEY;
  }

  async queryAI(service, prompt) {
    try {
      const url = service === 'ChatGPT' ? this.openAiUrl : this.anthropicUrl;
      const apiKey = service === 'ChatGPT' ? this.openAiApiKey : this.anthropicApiKey;
      const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      };

      console.log(`Sending request to ${service} with prompt: ${prompt}`);
      const response = await axios.post(url, { prompt }, { headers });
      console.log(`Received response from ${service}`);
      return response.data;
    } catch (error) {
      console.error(`Error querying ${service}:`, error.message);
      console.error(error.stack);
      throw new Error(`Failed to get response from ${service}`);
    }
  }
}

module.exports = new AIService();
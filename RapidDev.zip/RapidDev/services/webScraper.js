const axios = require('axios');
const cheerio = require('cheerio');
const dotenv = require('dotenv');
const CodingResource = require('../models/CodingResource');

dotenv.config();

class WebScraper {
  constructor() {
    this.codingPracticesUrl = process.env.CODING_PRACTICES_URL; // INPUT_REQUIRED {insert the URL for coding practices here}
    this.documentationUrl = process.env.DOCUMENTATION_URL; // INPUT_REQUIRED {insert the URL for documentation here}
  }

  async scrapeCodingPractices() {
    try {
      console.log("Starting to scrape coding practices.");
      const { data } = await axios.get(this.codingPracticesUrl);
      const $ = cheerio.load(data);
      const practices = [];
      $('#practices li').each((i, elem) => {
        practices.push($(elem).text());
      });

      await CodingResource.create({
        type: 'practice',
        content: practices
      });

      console.log("Successfully scraped and saved coding practices.");
      return practices;
    } catch (error) {
      console.error(`Error scraping coding practices: ${error.message}`);
      console.error(error.stack);
      throw error;
    }
  }

  async scrapeDocumentation() {
    try {
      console.log("Starting to scrape documentation.");
      const { data } = await axios.get(this.documentationUrl);
      const $ = cheerio.load(data);
      const docs = [];
      $('#docs a').each((i, elem) => {
        docs.push({
          title: $(elem).text(),
          url: $(elem).attr('href')
        });
      });

      await CodingResource.create({
        type: 'documentation',
        content: docs
      });

      console.log("Successfully scraped and saved documentation.");
      return docs;
    } catch (error) {
      console.error(`Error scraping documentation: ${error.message}`);
      console.error(error.stack);
      throw error;
    }
  }
}

module.exports = new WebScraper();
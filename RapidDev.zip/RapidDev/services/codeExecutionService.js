const Docker = require('dockerode');
const fs = require('fs');
const path = require('path');
const docker = new Docker();

class CodeExecutionService {
  async executeCode(language, code) {
    try {
      console.log(`Executing code in language: ${language}`);
      const codeFileName = this.getFileName(language);
      const codeFilePath = path.join(__dirname, "../executionEnvironment", codeFileName);
      fs.writeFileSync(codeFilePath, code);

      const container = await docker.createContainer({
        Image: "nikolaik/python-nodejs",
        Cmd: [this.getRunCommand(language, codeFileName)],
        AttachStdout: true,
        AttachStderr: true,
        Tty: false,
        HostConfig: {
          AutoRemove: true, // Automatically clean up container after execution
        },
        Binds: [`${codeFilePath}:/usr/src/app/${codeFileName}`],
      });

      await container.start();

      const stream = await container.logs({
        follow: true,
        stdout: true,
        stderr: true,
      });

      return new Promise((resolve, reject) => {
        const chunks = [];
        stream.on('data', (chunk) => chunks.push(chunk));
        stream.on('end', () => {
          const output = Buffer.concat(chunks).toString('utf8');
          console.log(`Execution output: ${output}`);
          resolve(output);
        });
        stream.on('error', (error) => {
          console.error('Error streaming container logs:', error);
          reject(error);
        });
      });
    } catch (error) {
      console.error('Error executing code:', error.message);
      console.error(error.stack);
      throw error;
    }
  }

  getFileName(language) {
    switch (language) {
      case 'python': return 'script.py';
      case 'nodejs': return 'script.js';
      case 'java': return 'Main.java';
      default: throw new Error('Unsupported language');
    }
  }

  getRunCommand(language, fileName) {
    switch (language) {
      case 'python': return `python ${fileName}`;
      case 'nodejs': return `node ${fileName}`;
      case 'java': return `javac ${fileName} && java Main`;
      default: throw new Error('Unsupported run command for language');
    }
  }
}

module.exports = new CodeExecutionService();
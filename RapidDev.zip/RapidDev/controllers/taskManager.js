const Task = require('../models/Task');
const AIService = require('../services/aiService');
const WebScraper = require('../services/webScraper');

class TaskManager {
  async createAndAssignTask(description, type) {
    try {
      console.log(`Creating task with description: ${description} and type: ${type}`);
      const task = await Task.create({ description, status: 'pending' });
      console.log(`Task created with ID: ${task._id}`);

      // Process task based on type (AI or scraping)
      if (type === 'AI') {
        this.processAITask(task);
      } else if (type === 'scraping') {
        this.processScrapingTask(task);
      } else {
        throw new Error('Invalid task type');
      }
    } catch (error) {
      console.error(`Error creating and assigning task: ${error.message}`);
      console.error(error.stack);
    }
  }

  async processAITask(task) {
    try {
      console.log(`Processing AI task with ID: ${task._id}`);
      task.status = 'in_progress';
      await task.save();

      // Example: Choosing AI service based on specific criteria
      const service = 'ChatGPT'; // or 'CLaude', depending on requirements
      const result = await AIService.queryAI(service, task.description);

      task.status = 'completed';
      task.result = result;
      await task.save();
      console.log(`AI task completed with ID: ${task._id}`);
    } catch (error) {
      task.status = 'failed';
      await task.save();
      console.error(`Error processing AI task with ID: ${task._id}: ${error.message}`);
      console.error(error.stack);
    }
  }

  async processScrapingTask(task) {
    try {
      console.log(`Processing scraping task with ID: ${task._id}`);
      task.status = 'in_progress';
      await task.save();

      let result;
      if (task.description === 'coding practices') {
        result = await WebScraper.scrapeCodingPractices();
      } else if (task.description === 'documentation') {
        result = await WebScraper.scrapeDocumentation();
      } else {
        throw new Error('Invalid scraping task description');
      }

      task.status = 'completed';
      task.result = result;
      await task.save();
      console.log(`Scraping task completed with ID: ${task._id}`);
    } catch (error) {
      task.status = 'failed';
      await task.save();
      console.error(`Error processing scraping task with ID: ${task._id}: ${error.message}`);
      console.error(error.stack);
    }
  }
}

module.exports = new TaskManager();